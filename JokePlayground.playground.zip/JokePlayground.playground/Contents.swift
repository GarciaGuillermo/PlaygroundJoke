import Cocoa

var one = "What drink did the vampire ask for when he went to the bar?"
var two = "Blood Light"

print (one + "\n")
print ("\t" + two)

